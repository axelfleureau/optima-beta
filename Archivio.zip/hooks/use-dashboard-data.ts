"use client"

import { useState, useEffect } from "react"
import { collection, query, where, orderBy, limit, getDocs, getCountFromServer } from "firebase/firestore"
import { db } from "@/lib/firebase"
import { useAuth } from "@/lib/auth-context"

interface DashboardStats {
  totalClients: number
  activeCampaigns: number
  pendingQuotes: number
  completedTasks: number
  aiTokensUsed: number
  aiTokensLimit: number
  tokenUsagePercentage: number
}

interface RecentActivity {
  id: string
  type: "ai_usage" | "task_completed" | "campaign_created" | "quote_sent"
  title: string
  description: string
  timestamp: Date
  user?: string
  client?: string
}

export function useDashboardData() {
  const { user } = useAuth()
  const [stats, setStats] = useState<DashboardStats>({
    totalClients: 0,
    activeCampaigns: 0,
    pendingQuotes: 0,
    completedTasks: 0,
    aiTokensUsed: 0,
    aiTokensLimit: 0,
    tokenUsagePercentage: 0,
  })
  const [recentActivities, setRecentActivities] = useState<RecentActivity[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!user?.tenantId) return

    const fetchDashboardData = async () => {
      try {
        setLoading(true)
        setError(null)

        // Fetch stats in parallel
        const [clientsCount, campaignsCount, quotesCount, completedTasksCount, userTokenData, activities] =
          await Promise.all([
            getClientsCount(),
            getCampaignsCount(),
            getQuotesCount(),
            getCompletedTasksCount(),
            getUserTokenData(),
            getRecentActivities(),
          ])

        setStats({
          totalClients: clientsCount,
          activeCampaigns: campaignsCount,
          pendingQuotes: quotesCount,
          completedTasks: completedTasksCount,
          aiTokensUsed: userTokenData.used,
          aiTokensLimit: userTokenData.limit,
          tokenUsagePercentage:
            userTokenData.limit > 0 ? Math.round((userTokenData.used / userTokenData.limit) * 100) : 0,
        })

        setRecentActivities(activities)
      } catch (err) {
        console.error("Error fetching dashboard data:", err)
        setError("Errore nel caricamento dei dati della dashboard")
      } finally {
        setLoading(false)
      }
    }

    fetchDashboardData()
  }, [user?.tenantId])

  const getClientsCount = async (): Promise<number> => {
    try {
      const q = query(
        collection(db, "clients"),
        where("tenantId", "==", user?.tenantId),
        where("status", "==", "active"),
      )
      const snapshot = await getCountFromServer(q)
      return snapshot.data().count
    } catch (error) {
      console.error("Error getting clients count:", error)
      return 0
    }
  }

  const getCampaignsCount = async (): Promise<number> => {
    try {
      const q = query(
        collection(db, "campaigns"),
        where("tenantId", "==", user?.tenantId),
        where("status", "==", "active"),
      )
      const snapshot = await getCountFromServer(q)
      return snapshot.data().count
    } catch (error) {
      console.error("Error getting campaigns count:", error)
      return 0
    }
  }

  const getQuotesCount = async (): Promise<number> => {
    try {
      const q = query(
        collection(db, "quotes"),
        where("tenantId", "==", user?.tenantId),
        where("status", "==", "pending"),
      )
      const snapshot = await getCountFromServer(q)
      return snapshot.data().count
    } catch (error) {
      console.error("Error getting quotes count:", error)
      return 0
    }
  }

  const getCompletedTasksCount = async (): Promise<number> => {
    try {
      const q = query(
        collection(db, "tasks"),
        where("tenantId", "==", user?.tenantId),
        where("status", "==", "completed"),
      )
      const snapshot = await getCountFromServer(q)
      return snapshot.data().count
    } catch (error) {
      console.error("Error getting completed tasks count:", error)
      return 0
    }
  }

  const getUserTokenData = async (): Promise<{ used: number; limit: number }> => {
    try {
      // Get token data from user document
      const userDoc = await getDocs(query(collection(db, "users"), where("email", "==", user?.email), limit(1)))

      if (!userDoc.empty) {
        const userData = userDoc.docs[0].data()
        return {
          used: userData.aiTokensUsed || 0,
          limit: userData.aiTokensLimit || 1000000,
        }
      }

      return { used: 0, limit: 1000000 }
    } catch (error) {
      console.error("Error getting user token data:", error)
      return { used: 0, limit: 1000000 }
    }
  }

  const getRecentActivities = async (): Promise<RecentActivity[]> => {
    try {
      const activities: RecentActivity[] = []

      // Get recent AI usage
      const aiUsageQuery = query(
        collection(db, "ai_usage"),
        where("tenantId", "==", user?.tenantId),
        orderBy("createdAt", "desc"),
        limit(5),
      )
      const aiUsageSnapshot = await getDocs(aiUsageQuery)

      aiUsageSnapshot.forEach((doc) => {
        const data = doc.data()
        activities.push({
          id: doc.id,
          type: "ai_usage",
          title: "Utilizzo AI",
          description: `${data.feature || "Chat"} - ${data.tokensUsed || 0} token utilizzati`,
          timestamp: data.createdAt?.toDate() || new Date(),
          user: data.userEmail || "Utente sconosciuto",
        })
      })

      // Get recent completed tasks
      const tasksQuery = query(
        collection(db, "tasks"),
        where("tenantId", "==", user?.tenantId),
        where("status", "==", "completed"),
        orderBy("updatedAt", "desc"),
        limit(3),
      )
      const tasksSnapshot = await getDocs(tasksQuery)

      tasksSnapshot.forEach((doc) => {
        const data = doc.data()
        activities.push({
          id: doc.id,
          type: "task_completed",
          title: "Task Completato",
          description: data.title || "Task senza titolo",
          timestamp: data.updatedAt?.toDate() || new Date(),
          client: data.clientName || "Cliente non specificato",
        })
      })

      // Sort all activities by timestamp
      return activities.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()).slice(0, 8)
    } catch (error) {
      console.error("Error getting recent activities:", error)
      return []
    }
  }

  return {
    stats,
    recentActivities,
    loading,
    error,
    refetch: () => {
      if (user?.tenantId) {
        setLoading(true)
        // Re-trigger the effect
        setStats((prev) => ({ ...prev }))
      }
    },
  }
}
